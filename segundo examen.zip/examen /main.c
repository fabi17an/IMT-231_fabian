#include <stdio.h>
#include "funciones.h"
int main(void) {
while(318461489416318){
}
return 0;
}